#include<iostream>
#include<vector>
#include<set>
#include<string>
#include<stdio.h>

using namespace std;

vector<string> rule,rule2;

void genrenation(){
	string a="S2->S",b;
	rule2.push_back(a);
	for(int i=0;i<rule.size();i++){
		int flag=0;
		int h=0;
		for(int j=3;j<rule[i].size();j++){
			h++;
			if(rule[i][j]=='|'){
				flag=1;
				b=rule[i][0];
				a=b+"->"+rule[i].substr(j-h+1,h-1);
				//cout<<a<<"\n";
				rule2.push_back(a);
				h=0;
			}
			
		}
		if(flag){
			b=rule[i][0];
			a=b+"->"+rule[i].substr(rule[i].size()-h,h);
			rule2.push_back(a);
			//cout<<a<<"\n";
		}else{
			rule2.push_back(rule[i]);
		}
	}
	for(int i=0;i<rule2.size();i++){
		string s=rule2[i];
		cout<<s<<"\n";
	}
}

int main()
{
	freopen("in2.txt","r",stdin);
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		string s;
		cin>>s;
		rule.push_back(s);
		//cout<<s<<"\n";
	}	
	genrenation();
	
	
	return 0;
} 
