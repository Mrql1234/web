#include<iostream>
#include<vector>
#include<set>
#include<string>
#include<stdio.h>
#include<map>
using namespace std;

string firstch;
struct Node{
	int a;
	char ch;
};
vector<Node> Dfa[20];

int cnt;
map<int,set<string> > R;
map<set<string>,int > R2;

vector<string> rule,rule2;

set<string> I0;

void genrenation(){  //�ع� 
	string a,b;
	a="H->"+firstch;        //
	rule2.push_back(a);
	for(int i=0;i<rule.size();i++){
		int flag=0;
		int h=0;
		for(int j=3;j<rule[i].size();j++){
			h++;
			if(rule[i][j]=='|'){
				flag=1;
				b=rule[i][0];
				a=b+"->"+rule[i].substr(j-h+1,h-1);
				//cout<<a<<"\n";
				rule2.push_back(a);
				h=0;
			}
			
		}
		if(flag){
			b=rule[i][0];
			a=b+"->"+rule[i].substr(rule[i].size()-h,h);
			rule2.push_back(a);
			//cout<<a<<"\n";
		}else{
			rule2.push_back(rule[i]);
		}
	}
	cout<<"�ع�Ϊ�ķ�G[H]:\n";
	for(int i=0;i<rule2.size();i++){
		string s=rule2[i];
		cout<<s<<"\n";
	}
	cout<<endl;
}

set<string> shift(set<string> s,char ch){ //��һ�����϶���һ���ַ���ļ��� 
	set<string> s2;
	string a;
	char b[2];             //���ַ�����ת��Ϊ�ַ��� ������string Ҫ���ַ�����ĩβ��\0 
	b[0]=ch;               
	b[1]='\0';
	set<string>::iterator it;
	for(it=s.begin();it!=s.end();it++){
		a=*it;
		for(int i=3;i<a.size()-1;i++){
			if(a[i]=='.'&&a[i+1]==ch){
				a=a.substr(0,i)+b+"."+a.substr(i+2,a.size()-i-2);
				s2.insert(a);
				break;
			}
		}
	}
	
	return s2;
}

set<string> f(char c,set<string> a){            //����ĳ�����ս����ͷ�Ĺ���д�����ϣ�
	string s;
	set<string> a2=a;
	for(int i=1;i<rule2.size();i++){
		if(rule2[i][0]==c){
			s=rule2[i].substr(0,3)+"."+rule2[i].substr(3,rule2[i].size()-3);
			//cout<<a<<"\n";
			a2.insert(s);
			if(s[3]=='.'&&s[4]>=65&&s[4]<=90){   //�ظ� 
				a2=f(s[4],a2); 
				
			} 
		}
	} 
	return a2;
}                   
void mI0(){       //����I0 
	string a;
	a="H->."+firstch;
	I0.insert(a);
	I0=f(firstch[0],I0);              
	R[0]=I0; cnt++;
	R2[I0]=0;

}

set<string> Closure(set<string> a){       //�󼯺ϵıհ�    
	string s;
	set<string> tmp=a;      //�ȰѼ���ȡ���� �����ȡ����Ԫ�غ�ļ��� 
	set<string>::iterator it;
	for(it=a.begin();it!=a.end();it++){
		s=*it;
		for(int i=3;i<s.size()-1;i++){  
			if(s[i]=='.'&&s[i+1]>=65&&s[i+1]<=90){
				tmp=f(s[i+1],a);
				break;
			}
			
		}
	}
	return tmp;
}
void mDfa(int a){     //����Dfa 
	Node n;
	//int num;
	string s;
	//char c;
	set<string> tmp=R[a];
	set<string>::iterator it;
	for(it=tmp.begin();it!=tmp.end();it++){  //��ǰ��Ŀ����Ŀ���.���ж������ַ����ж�����һ̬
		set<string> tmp2;
		s=*it;
		for(int i=3;i<s.size()-1;i++){         
			if(s[i]=='.'){
				tmp2=shift(tmp,s[i+1]);
				tmp2=Closure(tmp2);
				//cout<<tmp2.size()<<endl;
				
				if(R2.count(tmp2)){              //��map������������� 
					map<set<string>, int>::iterator it;
					it=R2.find(tmp2);
					
					//cout<<it->second;
					n.a=it->second;
					n.ch=s[i+1];
					Dfa[a].push_back(n);
					//cout<<n.a<<"  "<<n.ch<<endl;
					
				}else{
					//for(set<string>::iterator it=tmp2.begin();it!=tmp2.end();++it){
//   						cout<<*it<<"\n";	
//					}
//					cout<<endl;
					
					R[cnt]=tmp2;
					R2[tmp2]=cnt; 
					
					n.a=cnt;
					n.ch=s[i+1];
					Dfa[a].push_back(n);
					
					cnt++;    //�����ȼ�1 �����´ν������µ��û���ԭ��cnt 
					mDfa(cnt-1);
				}
				
				break;
			}
		}
	}
}


int main()
{
	freopen("in3.txt","r",stdin);
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		string s;
		cin>>s;
		rule.push_back(s);
		//cout<<s<<"\n";
	}	
	firstch=rule[0][0];
	genrenation();
	//cout<<shift("a.b")<<"\n";
	mI0();
	mDfa(0);
	
	cout<<cnt<<endl;
	
	for(int i=0;i<cnt;i++){
		set<string> s;
		s=R[i];
		cout<<"��Ŀ��"<<i<<endl; 
		for(set<string>::iterator it=s.begin();it!=s.end();it++){
			cout<<*it<<"\n";	
		}
		
	}
	cout<<endl;
	for(int i=0;i<cnt;i++){
		cout<<"��Ŀ��"<<i<<endl;
		
		for(int j=0;j<Dfa[i].size();j++){
			cout<<"����"<<Dfa[i][j].ch<<"����"<<Dfa[i][j].a<<endl;
			
		}
		cout<<endl;
	}

	
	return 0;
} 
