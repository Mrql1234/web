#include<iostream>
#include<vector>
#include<set>
#include<string>
#include<stdio.h>
#include<map>
using namespace std;

string firstch;
struct Node{
	int a;
	char ch;
};
vector<Node> Dfa[10];

int cnt;
map<int,set<string> > R;
map<set<string>,int > R2;

vector<string> rule,rule2;

set<string> I0;

void genrenation(){  //�ع� 
	string a,b;
	a="H->"+firstch;            //
	rule2.push_back(a);
	for(int i=0;i<rule.size();i++){
		int flag=0;
		int h=0;
		for(int j=3;j<rule[i].size();j++){
			h++;
			if(rule[i][j]=='|'){
				flag=1;
				b=rule[i][0];
				a=b+"->"+rule[i].substr(j-h+1,h-1);
				//cout<<a<<"\n";
				rule2.push_back(a);
				h=0;
			}
			
		}
		if(flag){
			b=rule[i][0];
			a=b+"->"+rule[i].substr(rule[i].size()-h,h);
			rule2.push_back(a);
			//cout<<a<<"\n";
		}else{
			rule2.push_back(rule[i]);
		}
	}
	cout<<"�ع�Ϊ�ķ�G[H]\n";
	for(int i=0;i<rule2.size();i++){
		string s=rule2[i];
		cout<<s<<"\n";
	}
	cout<<endl;
}

string shift(string s){  
	string a=s;
	for(int i=0;i<a.size();i++){
		if(a[i]=='.'){
			a[i]=a[i+1];
			a[i+1]='.';
			break;
		}
	}
	return a;
}

set<string> f(char c,set<string> a){                //����ĳ�����ս����ͷ���ķ�д�����ϣ�
	string s;
	set<string> a2=a;
	for(int i=1;i<rule2.size();i++){
		if(rule2[i][0]==c){
			s=rule2[i].substr(0,3)+"."+rule2[i].substr(3,rule2[i].size()-3);
			//cout<<a<<"\n";
			a2.insert(s);
			if(s[3]=='.'&&s[4]>=65&&s[4]<=90){   //�ظ� 
				a2=f(s[4],a2); 
				
			} 
		}
	} 
	return a2;
}                   
void mI0(){       //����I0 
	string a;
	a="H->."+firstch;
	I0.insert(a);
	//cout<<a<<"\n";
	//for(int i=1;i<rule2.size();i++){
//		if(rule2[i][0]==firstch[0]){
//			a=rule2[i].substr(0,3)+"."+rule2[i].substr(3,rule2[i].size()-3);
//			cout<<a<<"\n";
//			I0.insert(a);
//			if(rule2[i][3]>=65&&rule2[i][3]<=90){
//				f(rule2[i][3],0);
//			}
//		}
//	}
	
	
	I0=f(firstch[0],I0);              //
	R[0]=I0; cnt++;
	R2[I0]=0;
	
	//for(set<string>::iterator it=I0.begin();it!=I0.end();++it){
//		cout<<*it<<"\n";	
//	}
}

set<string> Closure(set<string> a){       //�󼯺ϵıհ�    
	string s;
	set<string> tmp=a;      //�ȰѼ���ȡ���� �����ȡ����Ԫ�غ�ļ��� 
	set<string>::iterator it;
	for(it=a.begin();it!=a.end();it++){
		s=*it;
		for(int i=3;i<s.size()-1;i++){  
			if(s[i]=='.'&&s[i+1]>=65&&s[i+1]<=90){
				tmp=f(s[i+1],a);
				break;
			}
			
		}
	}
	return tmp;
}
void mDfa(int a){     //����Dfa 
	Node n;
	//int num;
	string s;
	//char c;
	set<string> tmp=R[a];
	set<string>::iterator it;
	for(it=tmp.begin();it!=tmp.end();it++){
		set<string> tmp2;
		s=*it;
		for(int i=3;i<s.size()-1;i++){ 
			if(s[i]=='.'){
				tmp2.insert(shift(s));
				//cout<<tmp2.size()<<endl;
				tmp2=Closure(tmp2);
				//cout<<tmp2.size()<<endl;
				
				if(R2.count(tmp2)){                            //��map������������� 
					map<set<string>, int>::iterator it;
					it=R2.find(tmp2);
					
					//cout<<it->second;
					n.a=it->second;
					n.ch=s[i+1];
					Dfa[a].push_back(n);
					//cout<<n.a<<"  "<<n.ch<<endl;
					
				}else{
					//for(set<string>::iterator it=tmp2.begin();it!=tmp2.end();++it){
//   						cout<<*it<<"\n";	
//					}
					cout<<endl;
					R[cnt]=tmp2;
					R2[tmp2]=cnt; 
					
					n.a=cnt;
					n.ch=s[i+1];
					Dfa[a].push_back(n);
					//cout<<n.a<<"  "<<n.ch<<endl;
					mDfa(cnt);
					
					cnt++;
				}
				
				break;
			}
		}
	}
}


int main()
{
	freopen("in3.txt","r",stdin);
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		string s;
		cin>>s;
		rule.push_back(s);
		//cout<<s<<"\n";
	}	
	firstch=rule[0][0];
	genrenation();
	//cout<<shift("a.b")<<"\n";
	mI0();
	mDfa(0);
	//cout<<cnt<<endl;
	
	for(int i=0;i<cnt;i++){
		cout<<"��Ŀ"<<i<<endl;
		
		for(int j=0;j<Dfa[i].size();j++){
			cout<<Dfa[i][j].a<<"  "<<Dfa[i][j].ch<<endl;
		}
		cout<<endl;
	}

//	for(int i=0;i<cnt;i++){
//		set<string> s;
//		s=R[i];
//		cout<<"��Ŀ��"<<i<<endl; 
//		for(set<string>::iterator it=s.begin();it!=s.end();it++){
//			cout<<*it<<"\n";	
//		}
//		
//	}
	return 0;
} 
