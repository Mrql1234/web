#include<iostream>
#include<vector>
#include<set>
#include<string>
#include<stdio.h>
#include<map>
using namespace std;
string firstch;
struct Node{
	int a;
	char ch;
};
map<int,set<string> > R;

vector<string> rule,rule2;

vector<Node> Dfa[10];

set<string> I0;

void genrenation(){  //�ع� 
	string a,b;
	a="S2->"+firstch;
	rule2.push_back(a);
	for(int i=0;i<rule.size();i++){
		int flag=0;
		int h=0;
		for(int j=3;j<rule[i].size();j++){
			h++;
			if(rule[i][j]=='|'){
				flag=1;
				b=rule[i][0];
				a=b+"->"+rule[i].substr(j-h+1,h-1);
				//cout<<a<<"\n";
				rule2.push_back(a);
				h=0;
			}
			
		}
		if(flag){
			b=rule[i][0];
			a=b+"->"+rule[i].substr(rule[i].size()-h,h);
			rule2.push_back(a);
			//cout<<a<<"\n";
		}else{
			rule2.push_back(rule[i]);
		}
	}
	for(int i=0;i<rule2.size();i++){
		string s=rule2[i];
		cout<<s<<"\n";
	}
}

string shift(string s){  
	string a=s;
	for(int i=0;i<a.size();i++){
		if(a[i]=='.'){
			a[i]=a[i+1];
			a[i+1]='.';
			break;
		}
	}
	return a;
}

void f(char c){              //����ĳ�����ս����ͷ���ķ�д��I0��
	string a;
	//cout<<a<<"\n";
	for(int i=1;i<rule2.size();i++){
		if(rule2[i][0]==c){
			a=rule2[i].substr(0,3)+"."+rule2[i].substr(3,rule2[i].size()-3);
			//cout<<a<<"\n";
			I0.insert(a);
			
		}
	} 
}                   
void mI0(){       //����I0 
	string a;
	a="S2->."+firstch;
	I0.insert(a);
	//cout<<a<<"\n";
	for(int i=1;i<rule2.size();i++){
		if(rule2[i][0]==firstch[0]){
			a=rule2[i].substr(0,3)+"."+rule2[i].substr(3,rule2[i].size()-3);
			//cout<<a<<"\n";
			I0.insert(a);
			if(rule2[i][3]>=65&&rule2[i][3]<=90){
				f(rule2[i][3]);
			}
		}
	} 
}

int main()
{
	freopen("in3.txt","r",stdin);
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		string s;
		cin>>s;
		rule.push_back(s);
		//cout<<s<<"\n";
	}	
	firstch=rule[0][0];
	genrenation();
	//cout<<shift("a.b")<<"\n";
	mI0();
	for(set<string>::iterator it=I0.begin();it!=I0.end();++it){
		cout<<*it<<"\n";
		
	}
	return 0;
} 
